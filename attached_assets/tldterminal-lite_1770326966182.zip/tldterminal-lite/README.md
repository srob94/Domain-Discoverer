# TLDTerminal Lite (Frontend Mock)

This is a frontend-only MVP scaffold for TLDTerminal.

## Features
- Daily Drop Feed (mock JSON)
- Watchlist + Saved Searches UI stubs
- Supabase client configured (auth/db ready)

## Setup
```bash
npm install
npm run dev
```

## Supabase
Create `.env.local`:

```
NEXT_PUBLIC_SUPABASE_URL=[your_url]
NEXT_PUBLIC_SUPABASE_ANON_KEY=[your_key]
```
