import domains from '../data/mockDomains.json'

export default function Home() {
  return (
    <main style={{ padding: 24, fontFamily: 'system-ui' }}>
      <h1>TLDTerminal Lite — Daily Drop Feed</h1>
      <p>Mock data feed (MVP scaffold)</p>

      <div style={{ marginTop: 24 }}>
        {domains.map((d) => (
          <div key={d.fqdn} style={{
            border: '1px solid #ddd',
            borderRadius: 12,
            padding: 16,
            marginBottom: 12
          }}>
            <h2>{d.fqdn} — Score {d.score}</h2>
            <p>Status: {d.status} • Drops in: {d.dropsIn}</p>
            <p>Renewal: ${d.renewal}/yr {d.premium ? "⚠️ Premium Renewal" : ""}</p>
            <button>Watch</button>
          </div>
        ))}
      </div>
    </main>
  )
}
